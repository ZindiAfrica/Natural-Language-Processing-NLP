## Zindi sgds text classification

* Blendedensemble: using blending ensembles
* kfoldtest.ipynb: using NBSVM
* ensembles.ipynb: ensemble model output based on correlation with other model